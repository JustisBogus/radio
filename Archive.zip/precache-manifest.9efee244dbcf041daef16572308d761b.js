self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e8a8217f447116851dbaf23fa0a61a5a",
    "url": "/showcase/radio/index.html"
  },
  {
    "revision": "0a55f34abba5ba4bdc87",
    "url": "/showcase/radio/static/css/main.66acd44c.chunk.css"
  },
  {
    "revision": "fb91313f53954f35e344",
    "url": "/showcase/radio/static/js/2.cd7800ba.chunk.js"
  },
  {
    "revision": "0a55f34abba5ba4bdc87",
    "url": "/showcase/radio/static/js/main.a9fd77fc.chunk.js"
  },
  {
    "revision": "54e3705e35b65b0e177c",
    "url": "/showcase/radio/static/js/runtime~main.3ec88b82.js"
  },
  {
    "revision": "8b358c45871564e51ffdb25e09b26eae",
    "url": "/showcase/radio/static/media/back-arrow.8b358c45.png"
  },
  {
    "revision": "3a0c76ad0e075df488bc636898762f25",
    "url": "/showcase/radio/static/media/switch.3a0c76ad.png"
  }
]);